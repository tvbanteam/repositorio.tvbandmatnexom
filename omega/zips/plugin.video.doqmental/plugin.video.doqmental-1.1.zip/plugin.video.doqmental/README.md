# Plugintools
Plugintools, created by Jesus from pelisalacarta

![](https://img.shields.io/badge/Python-2-blue)
![](https://img.shields.io/badge/Python-3-blue)

## Requires
Script.module.six

## Version
<strong>Current Version: 1.0.9</strong>
|Version|Changelog|
|---|-----------|
|1.0.9|Compatibility with Kodi 19|
